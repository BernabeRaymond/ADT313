function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Child component</p>
    </div>
  );
}

export default Dashboard;
