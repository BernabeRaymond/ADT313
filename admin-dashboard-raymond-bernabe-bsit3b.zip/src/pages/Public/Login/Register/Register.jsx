import { useState } from 'react';

import './Register.css'; 
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [status, setStatus] = useState('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleOnChange = (event, setter) => {
    setter(event.target.value);
    setErrors({});
    setErrorMessage('');
  };

  const validateForm = () => {
    const newErrors = {};
    if (!firstName) newErrors.firstName = 'First name is required';
    if (!lastName) newErrors.lastName = 'Last name is required';
    if (!email) newErrors.email = 'Email is required';
    if (!password) newErrors.password = 'Password is required';
    if (!contactNumber) newErrors.contactNumber = 'Contact number is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleRegister = async (e) => {
    e.preventDefault(); // Prevent default form submission

    if (!validateForm()) return;

    const data = { email, password, firstName, middleName, lastName, contactNumber };
    setStatus('loading');

    try {
      await axios.post('/admin/register', data);
      navigate('/login'); 
    } catch (error) {
      setErrorMessage(error.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setStatus('idle');
    }
  };

  return (
    <div className='Register'>
      <div className='main-container'>
        <h3>Register</h3>
        <form onSubmit={handleRegister}>
          <div className='form-container'>
            <div className='form-group'>
              <label>First Name:</label>
              <input
                type='text'
                value={firstName}
                onChange={(e) => handleOnChange(e, setFirstName)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
              {errors.firstName && <span className='errors'>{errors.firstName}</span>}
            </div>
            <div className='form-group'>
              <label>Middle Name:</label>
              <input
                type='text'
                value={middleName}
                onChange={(e) => handleOnChange(e, setMiddleName)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
            </div>
            <div className='form-group'>
              <label>Last Name:</label>
              <input
                type='text'
                value={lastName}
                onChange={(e) => handleOnChange(e, setLastName)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
              {errors.lastName && <span className='errors'>{errors.lastName}</span>}
            </div>
            <div className='form-group'>
              <label>E-mail:</label>
              <input
                type='email'
                value={email}
                onChange={(e) => handleOnChange(e, setEmail)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
              {errors.email && <span className='errors'>{errors.email}</span>}
            </div>
            <div className='form-group'>
              <label>Password:</label>
              <input
                type='password'
                value={password}
                onChange={(e) => handleOnChange(e, setPassword)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
              {errors.password && <span className='errors'>{errors.password}</span>}
            </div>
            <div className='form-group'>
              <label>Contact Number:</label>
              <input
                type='tel'
                value={contactNumber}
                onChange={(e) => handleOnChange(e, setContactNumber)}
                onKeyPress={(e) => e.key === 'Enter' && handleRegister(e)}
              />
              {errors.contactNumber && <span className='errors'>{errors.contactNumber}</span>}
            </div>
            <div className='submit-container'>
              <button type='submit' disabled={status === 'loading'}>
                {status === 'idle' ? 'Register' : 'Loading...'}
              </button>
            </div>
            {errorMessage && <span className='errors'>{errorMessage}</span>}
            <div className='login-container'>
              <a href='/login'>
                <small>Already have an account? Login</small>
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Register;
